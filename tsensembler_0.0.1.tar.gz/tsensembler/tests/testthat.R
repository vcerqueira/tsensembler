library(testthat)
library(tsensembler)

test_check("tsensembler")
